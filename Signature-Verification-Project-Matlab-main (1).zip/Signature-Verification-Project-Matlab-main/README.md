# Signature-Verification-Project-Matlab

->  Database Preparation

->	Scanner Specification

->	Filtering

->	Binarization

->	Conversion of Gray level image into binary image

->	Cropping

->	Thinning

->	Skeletonization

->	Rotation for Skew Correction

->	Resizing

->	Aspect Ratio ( Signature Width To height ratio )

->	Horizontal and vertical center of the signature

![01](https://user-images.githubusercontent.com/97385283/190892549-b7d11375-2d54-43c6-a904-45bab12ae0c5.png)
![02](https://user-images.githubusercontent.com/97385283/190892551-10976214-b4bb-40d0-a8ff-0bdbf9b428df.png)
![03](https://user-images.githubusercontent.com/97385283/190892553-f2449af6-d539-4f7a-be35-ec607df6f934.png)
![04](https://user-images.githubusercontent.com/97385283/190892554-e32c0ab8-45dc-4c66-9df1-df422c5d845f.png)
![05](https://user-images.githubusercontent.com/97385283/190892556-0b94aa70-c536-4265-9f40-5fb0085d38d4.png)
![06](https://user-images.githubusercontent.com/97385283/190892557-7930f26c-b71c-4bb3-91eb-38ddd8bc94b1.png)

# My Youtube proper video demo upload  
https://www.youtube.com/@easycodeproject



# Do you want to create or redesign an amazing website for your business and rank it on the first page of Google?
# We are providing attractive offers, discounts, and benefits on some of our most demanding services like
• New Website Development and Redesign
• Mobile App Development
• Custom Software Development
• Branding & Graphics
• App Development
• CMS Development
• Blockchain Development
• Search Engine Optimization

We recognize the significance of a cost-effective strategy. We are excited to provide significant discounts and advantages on our most popular services.
Let's set up a time to speak about your individual needs and goals, as well as how NetSear can personalize our services to improve your online visibility.

# ► ➜ Business_Email: info@netsear.com
# ► ➜ Website:  https://netsear.com/
# ► ➜ Linkedin: netsear
